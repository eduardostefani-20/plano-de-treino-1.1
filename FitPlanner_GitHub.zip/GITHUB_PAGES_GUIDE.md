# Guia de Publicação no GitHub Pages para FitPlanner

Este guia detalha os passos para publicar o projeto FitPlanner usando o GitHub Pages, tornando-o acessível publicamente na web.

## Pré-requisitos

*   Uma conta no GitHub.
*   Git instalado e configurado em sua máquina local.
*   O projeto FitPlanner (os arquivos `index.html`, `README.md`, etc.) em um repositório GitHub.

## Passos para Publicar

### 1. Crie um Repositório no GitHub

Se você ainda não tem um repositório para o FitPlanner, siga estes passos:

1.  No GitHub, clique no botão `+` no canto superior direito e selecione `New repository`.
2.  Dê um nome ao seu repositório (ex: `FitPlanner`).
3.  Escolha se o repositório será `Public` ou `Private`.
4.  **Não** inicialize o repositório com um README, `.gitignore` ou licença, pois você adicionará os arquivos existentes.
5.  Clique em `Create repository`.

### 2. Envie o Projeto para o Repositório

Se você já tem os arquivos do FitPlanner localmente, siga estas instruções para enviá-los para o seu novo repositório:

1.  Abra o terminal ou prompt de comando na pasta raiz do seu projeto FitPlanner (onde estão `index.html`, `README.md`, etc.).
2.  Inicialize um repositório Git local:
    ```bash
    git init
    ```
3.  Adicione todos os arquivos ao stage:
    ```bash
    git add .
    ```
4.  Faça o primeiro commit:
    ```bash
    git commit -m "Initial commit: FitPlanner project files"
    ```
5.  Adicione o repositório remoto do GitHub. Substitua `SEU_USUARIO` e `SEU_REPOSITORIO` pelos seus dados:
    ```bash
    git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
    ```
6.  Envie os arquivos para o GitHub:
    ```bash
    git push -u origin main
    ```
    *Nota: O branch padrão pode ser `master` em vez de `main`. Verifique no seu repositório GitHub.* 

### 3. Configure o GitHub Pages

Agora que o código está no GitHub, você pode configurar o GitHub Pages:

1.  No seu repositório GitHub, clique na aba `Settings`.
2.  No menu lateral esquerdo, clique em `Pages`.
3.  Na seção `Source`, selecione o branch `main` (ou `master`) e a pasta `/ (root)`.
4.  Clique em `Save`.

### 4. Acesse seu Site

Após salvar as configurações, o GitHub Pages levará alguns minutos para construir e publicar seu site. Você verá uma mensagem indicando que seu site está pronto em um endereço como:

`https://SEU_USUARIO.github.io/SEU_REPOSITORIO/`

Por exemplo, se seu usuário for `octocat` e o repositório `FitPlanner`, o endereço será `https://octocat.github.io/FitPlanner/`.

## Dicas Adicionais

*   **Atualizações**: Para atualizar seu site, basta fazer `git commit` e `git push` para o branch configurado (`main` ou `master`). O GitHub Pages detectará as mudanças e reconstruirá o site automaticamente.
*   **Domínio Personalizado**: Você pode configurar um domínio personalizado para seu site GitHub Pages na mesma seção `Settings > Pages`.

Com estes passos, seu FitPlanner estará online e acessível para todos!
