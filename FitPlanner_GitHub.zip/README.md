# FitPlanner - Elite Training System

![FitPlanner Logo](https://via.placeholder.com/400x200?text=FitPlanner+Logo) <!-- Placeholder para o logo -->

## Visão Geral

O FitPlanner é um sistema de treinamento de elite projetado para otimizar seus treinos, dieta e acompanhamento de progresso. Desenvolvido com React e JavaScript puro, este projeto oferece uma interface intuitiva para gerenciar sua jornada fitness.

## Funcionalidades

*   **Dashboard Interativo**: Visualize suas métricas de treino, consumo de água e metas diárias.
*   **Plano de Treino Detalhado**: Acesse planos de treino semanais com exercícios, séries, repetições, tempo de descanso e notas específicas.
*   **Guia de Nutrição**: Obtenha recomendações de dieta com refeições detalhadas, macros e calorias.
*   **Acompanhamento de Progresso**: Monitore sua evolução de peso, percentual de gordura corporal e fotos de progresso.
*   **Responsivo**: Design adaptável para desktop e dispositivos móveis.

## Otimizações Realizadas

Este projeto passou por um processo de otimização focado em:

*   **Performance**: Melhorias no carregamento de fontes e scripts externos, garantindo maior segurança e eficiência.
*   **Manutenibilidade**: Separação de dados (planos de treino, nutrição) da lógica dos componentes, facilitando futuras atualizações e extensões.
*   **Acessibilidade e Semântica**: Uso de tags HTML semânticas e atributos ARIA para melhorar a acessibilidade e a estrutura do documento, beneficiando usuários de tecnologias assistivas e SEO.

Para mais detalhes sobre as otimizações, consulte o `relatorio_otimizacao_fitplanner.md`.

## Como Usar

1.  **Clone o Repositório**:
    ```bash
    git clone https://github.com/SEU_USUARIO/FitPlanner.git
    cd FitPlanner
    ```
2.  **Abra no Navegador**: Como este é um projeto HTML/CSS/JS puro, basta abrir o arquivo `index_otimizado.html` diretamente no seu navegador.

## Estrutura do Projeto

```
FitPlanner/
├── index_otimizado.html
├── relatorio_otimizacao_fitplanner.md
└── README.md
```

## Contribuição

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou enviar pull requests.

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes. <!-- Adicionar arquivo LICENSE posteriormente -->

## Contato

Para dúvidas ou sugestões, entre em contato em [seu_email@example.com](mailto:seu_email@example.com).
