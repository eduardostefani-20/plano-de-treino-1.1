# FitPlanner - Elite Training System

![FitPlanner Logo](https://via.placeholder.com/400x200?text=FitPlanner+Logo) <!-- Placeholder for the logo -->

## Overview

FitPlanner is an elite training system designed to optimize your workouts, diet, and progress tracking. Developed with React and plain JavaScript, this project offers an intuitive interface to manage your fitness journey.

## Features

*   **Interactive Dashboard**: Visualize your workout metrics, water intake, and daily goals.
*   **Detailed Training Plan**: Access weekly training plans with exercises, sets, reps, rest times, and specific notes.
*   **Nutrition Guide**: Get diet recommendations with detailed meals, macros, and calories.
*   **Progress Tracking**: Monitor your weight evolution, body fat percentage, and progress photos.
*   **Responsive Design**: Adaptive design for desktop and mobile devices.

## Optimizations Performed

This project underwent an optimization process focused on:

*   **Performance**: Improvements in font and external script loading, ensuring greater security and efficiency.
*   **Maintainability**: Separation of data (training plans, nutrition) from component logic, facilitating future updates and extensions.
*   **Accessibility and Semantics**: Use of semantic HTML tags and ARIA attributes to improve accessibility and document structure, benefiting assistive technology users and SEO.

For more details on the optimizations, please refer to `relatorio_otimizacao_fitplanner.md`.

## How to Use

1.  **Clone the Repository**:
    ```bash
    git clone https://github.com/YOUR_USERNAME/FitPlanner.git
    cd FitPlanner
    ```
2.  **Open in Browser**: As this is a pure HTML/CSS/JS project, simply open the `index_otimizado.html` file directly in your browser.

## Project Structure

```
FitPlanner/
├── index_otimizado.html
├── relatorio_otimizacao_fitplanner.md
├── README.md
└── README_en.md
```

## Contribution

Contributions are welcome! Feel free to open issues or submit pull requests.

## License

This project is licensed under the MIT License. See the `LICENSE` file for more details. <!-- Add LICENSE file later -->

## Contact

For questions or suggestions, please contact [your_email@example.com](mailto:your_email@example.com).
